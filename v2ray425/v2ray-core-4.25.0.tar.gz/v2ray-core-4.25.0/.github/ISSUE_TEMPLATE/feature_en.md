---
name: Feature Request
about: "Open a feature request to V2Ray"
---

Please describe the new feature you want in detail.

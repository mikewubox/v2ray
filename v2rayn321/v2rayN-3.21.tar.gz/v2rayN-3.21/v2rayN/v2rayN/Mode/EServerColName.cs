﻿
namespace v2rayN.Mode
{
    public enum EServerColName
    {
        def = 0,
        configType,
        remarks,
        address,
        port,
        security,
        network,
        subRemarks,
        testResult,

        todayDown,
        todayUp,
        totalDown,
        totalUp
    }
}